

class JwtAuthMiddlewareStack:
    pass