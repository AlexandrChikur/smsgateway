# from rest_framework.generics import get_object_or_404
# from rest_framework.response import Response
# from rest_framework.views import APIView
#
# from .models import Message
# from .serializers import MessageSerializer
#
#
# class MessageListAPIView(APIView):
#     def get(self, request, id: int = None):
#         if id:
#             msg = get_object_or_404(Message, id=id)
#             s = MessageSerializer(msg)
#         else:
#             msgs = Message.objects.filter(author_id=request.user.id)
#             s = MessageSerializer(msgs, many=True)
#
#         return Response(s.data)
