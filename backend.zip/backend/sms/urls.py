from django.urls import path

from backend.sms.views import MessageCreateView
from backend.sms.views import MessagesListView

urlpatterns = [
    path('', MessagesListView.as_view(), name="url_messages_list"),
    path('add/', MessageCreateView.as_view(), name="url_message_add"),

    # path('add/', api_view.MessageListAPIView.as_view()),
    # path('api/add/', TestAPIView.as_view()),
]
